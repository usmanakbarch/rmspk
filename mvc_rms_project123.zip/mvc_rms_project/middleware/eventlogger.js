
//EventLogger
const file = require('fs');
async function EventLog (req,res,next){
    console.log(`URL >> ${req.url}  |  ${req.ip}  |  ${Date()}`);
    file.appendFileSync('EventLog.txt', `URL >> ${req.originalurl}  |  ${req.ip}  |  ${Date()} \n`);
    next();
}

module.exports={EventLog};