
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const {User} = require('../models/usersModel');

passport.use(new LocalStrategy(
  async (username, password, done) => {
    try {
      console.log('Received Credentials: ', username, password);
      const user = await User.findOne({ username: username });
      if (!user) {
        return done(null, false, { message: 'Incorrect Username.' })
      }
      console.log("User exist");  //Check
      const isPasswordMatch = user.password == password ? true : false;

      if (isPasswordMatch) {
        return done(null, user);
      }
      else {
        return done(null, false, { message: 'Incorrect Password.' });
      }
    }
    catch (err) {
      return done(err);
    }
  }
));

module.exports = {passport}