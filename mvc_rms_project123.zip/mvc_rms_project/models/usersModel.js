// Schema and Model for (System User)
const db = require('mongoose');
const {db_connect} = require('../config/database');
db_connect();

const userSchema = new db.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
    },
    username: {
        type: String,
        required: true,
        minlength: 4,
    },
    password: {
        type: String,
        required: true,
        minlength: 4,
    }
})

const User = db.model('users', userSchema);                       // User Model
module.exports = { User };