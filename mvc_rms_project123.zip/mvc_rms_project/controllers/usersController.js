// usersController.js
const { model } = require('mongoose');
const path = require('path');
const { User } = require('../models/usersModel');
const bcrypt = require('bcrypt');

async function handleGetAllUsers(req, res) {
    try {
        const allUsers = await User.find();                                                           //getting data from db
        res.status(201).json(allUsers);                  //Data view to client-side
    } catch (error) {
        res.status(400).json({ msg: "Error in Data Fetching", err: error });
    }
}

async function handleGetTableUsers(req, res) {
    res.sendFile(path.join(__dirname, "../views/user_list.html"));
}

async function handleGetPasswordChangeForm(req, res) {
    res.sendFile(path.join(__dirname, "../views/user_update.html"));
}

async function handleGetSignupForm(req, res) {
    res.sendFile(path.join(__dirname, "../views/signup.html"));
}

async function handleGetUserDeleteForm(req, res) {
    res.sendFile(path.join(__dirname, "../views/user_delete.html"));
}

async function handleNewUser(req, res) {
    try {
        // const newUser = new User(req.body);
        const {name, email, username, password} = req.body;
        const slat = bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, slat);
        const newUser = new User({
            name,
            email,
            username,
            password:hashedPassword,
        })
        const savedUser = await newUser.save();                                                           //data saving to db
        // res.status(201).json({msg:"New User Saved", data: savedUser});                  //msg to client-side
        res.redirect('/user/list')
    } catch (error) {
        res.status(400).json({ msg: "Error in New_User Saving", err: error });
    }
}

async function handleDeleteUser(req, res) {
    try {
        const userEmail = (req.body.email);
        const isDelete = await User.findOneAndDelete(
            { email: userEmail },      //filter
            { new: true }
        );
        if (isDelete) {
            res.status(201).json({ msg: "User Delete" });
        }
        else {
            res.status(404).json({ msg: "User Not Found", err: error });
        }
    } catch (error) {
        res.status(500).json({ message: 'Internal Server Error', SERVER_ERROR: error });
    }
}

async function handleUserPasswordChange(req, res) {
    try {
        const userEmail = (req.body.email);
        const userNewPassword = (req.body.password);
        // userNewPassword = bcrypt.hash(userNewPassword, 10);
        const changePassword = await User.findOneAndUpdate(
        
            { email: userEmail },                                          //filter
            { $set: { password: userNewPassword } },      //Update value
            { new: true }
        );
        if (changePassword) {
            res.status(201).json({ msg: "Password Update for ", email: userEmail });
        }
        else {
            res.status(404).json({ msg: "User Not Found", err: error });
        }
    } catch (error) {
        res.status(500).json({ message: 'Internal Server Error', SERVER_ERROR: error.nam });
    }
}



module.exports = {
    handleGetAllUsers,
    handleGetTableUsers,
    handleNewUser,
    handleUserPasswordChange,
    handleGetPasswordChangeForm,
    handleGetSignupForm,
    handleGetUserDeleteForm,
    handleDeleteUser,

}