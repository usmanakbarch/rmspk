const express = require('express');
const loginRouter = express.Router();
const passport = require('../auth');

const path = require('path');

loginRouter.get('/' , (req , res)=>{
   res.sendFile(path.join(__dirname, '../views/login.html'));
})

// Login Endpoint
loginRouter.post('/', passport.authenticate('local', {
  session : true,
  successRedirect: '/dashboard', // Redirect on success
  failureRedirect: '/login', // Redirect on failure
  failureFlash: true, // Enable error messages
}));

module.exports = {loginRouter,passport};
