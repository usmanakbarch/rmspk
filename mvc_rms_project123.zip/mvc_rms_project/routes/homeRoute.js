
const express = require('express');
const home = express.Router();
const path = require('path');

//Home
home.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, '../views/app_nav.html'));
});

module.exports={home};