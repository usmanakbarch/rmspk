//User Router
const express = require('express');
const path = require('path');
const userRouter = express.Router();

//Import Model {User}
const { User } = require('../models/usersModel');

//Import Controller
const { 
    handleGetAllUsers,
    handleNewUser,
    handleGetTableUsers,
    handleUserPasswordChange,
    handleGetPasswordChangeForm,
    handleGetSignupForm,
    handleGetUserDeleteForm,
    handleDeleteUser } = require('../controllers/usersController');

// User Controllers
userRouter.get('/viewall', handleGetAllUsers);
userRouter.post('/signup', handleNewUser);
userRouter.get('/list', handleGetTableUsers);
userRouter.get('/signup', handleGetSignupForm);
userRouter.get('/update', handleGetPasswordChangeForm);
userRouter.post('/update',  handleUserPasswordChange);
userRouter.get('/delete', handleGetUserDeleteForm);
userRouter.post('/delete', handleDeleteUser);

module.exports = { userRouter };