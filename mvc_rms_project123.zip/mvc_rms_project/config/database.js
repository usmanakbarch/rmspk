//Database Connection

const express = require('express');

async function db_connect() {
    const db = require('mongoose');
    const connectionString = 'mongodb://localhost:27017/resturant';

    db.connect(connectionString)
        .then(() => console.log('Connected to MongoDB'))
        .catch((err) => console.error('Connection error', err));
}
module.exports = { db_connect };

